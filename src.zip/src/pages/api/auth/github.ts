import type { APIRoute } from 'astro';
import { eq } from 'drizzle-orm';
import { db } from '../../../db';
import { users, sessions } from '../../../db/schema';
import { generateToken } from '../../../lib/auth';
import { getGitHubUser } from '../../../lib/github';

// Disable prerendering for this route
export const prerender = false;

export const GET: APIRoute = async ({ request, cookies, redirect }) => {
  console.log('=== GitHub Auth Callback Start ===');
  console.log('Request URL:', request.url);
  console.log('Request method:', request.method);
  console.log('Request headers:', Object.fromEntries(request.headers.entries()));
  
  const url = new URL(request.url);
  console.log('Parsed URL:', {
    href: url.href,
    pathname: url.pathname,
    search: url.search,
    searchParams: Object.fromEntries(url.searchParams.entries())
  });
  
  const code = url.searchParams.get('code');
  console.log('Extracted code:', code);
  
  if (!code) {
    console.log('No code found in URL params');
    return redirect('/login?error=no_code');
  }

  try {
    console.log('Starting GitHub user info fetch with code:', code);
    // Get GitHub user info
    const githubUser = await getGitHubUser(code);
    
    if (!githubUser) {
      console.log('Failed to get GitHub user info');
      return redirect('/login?error=github_auth_failed');
    }

    console.log('Successfully got GitHub user:', { 
      id: githubUser.id, 
      login: githubUser.login,
      email: githubUser.email 
    });

    // Find or create user
    let user = await db.query.users.findFirst({
      where: eq(users.email, githubUser.email)
    });

    if (!user) {
      const [newUser] = await db.insert(users).values({
        id: crypto.randomUUID(),
        email: githubUser.email,
        name: githubUser.name,
        avatar: githubUser.avatar_url,
      }).returning();
      user = newUser;
    }

    // Create session
    const sessionId = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000); // 30 days

    await db.insert(sessions).values({
      id: sessionId,
      userId: user.id,
      expiresAt,
    });

    // Set session cookie
    cookies.set('session', sessionId, {
      path: '/',
      httpOnly: true,
      secure: import.meta.env.PROD,
      sameSite: 'lax',
      maxAge: 30 * 24 * 60 * 60, // 30 days
    });

    return redirect('/admin');
  } catch (error) {
    console.error('Auth error:', error);
    return redirect('/login?error=auth_failed');
  }
}; 